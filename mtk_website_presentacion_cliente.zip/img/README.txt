Imágenes referenciadas desde pixabay.com para fondos y secciones.
https://cdn.pixabay.com/photo/2016/11/21/15/47/cleaning-1845800_1280.jpg
https://cdn.pixabay.com/photo/2017/08/06/17/04/computer-2593922_1280.jpg
https://cdn.pixabay.com/photo/2017/03/28/12/10/window-cleaner-2186710_1280.jpg
https://cdn.pixabay.com/photo/2015/06/24/16/36/wedding-820300_1280.jpg
